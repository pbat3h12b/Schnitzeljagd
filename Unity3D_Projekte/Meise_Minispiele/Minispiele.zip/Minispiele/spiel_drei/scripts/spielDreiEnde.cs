﻿using UnityEngine;
using System.Collections;

public class spielDreiEnde : MonoBehaviour {

	//Fabian Meise

	float timer = 25;
	

	// Update is called once per frame
	void Update () {
		 timer -=Time.deltaTime;
		if (timer == 0) {
			GameOver ();
		}

	}

	void GameOver(){
		//Application.LoadLevel ();
	}
}
